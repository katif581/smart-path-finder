# Smart Path Finder

A Django web application that demonstrates pathfinding algorithms on a Google Map. It contains a manually created 15-node weighted graph around Dhaka and supports BFS, DFS, Dijkstra, and A*.

## Requirements
- Python 3.10+
- Google Maps JavaScript API key
- Internet connection for Google Maps

## Setup

1. Extract the project ZIP and open a terminal in the `SmartPathFinder` folder.
2. Create and activate a virtual environment:

   **Windows**
   ```bash
   python -m venv venv
   venv\\Scripts\\activate
   ```

   **macOS/Linux**
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Get a Google Maps JavaScript API key from Google Cloud Console. Enable billing and the **Maps JavaScript API** for the project. Restrict the key to your website/referrer when deploying.

5. Open `pathfinder/views.py` and replace:
   ```python
   "YOUR_GOOGLE_MAPS_API_KEY"
   ```
   with your actual key. Do not publish your key in a public repository.

6. Run migrations and start Django:
   ```bash
   python manage.py migrate
   python manage.py runserver
   ```

7. Open http://127.0.0.1:8000/ in your browser.

## How to use
- Choose a source and destination from the dropdowns.
- Select BFS, DFS, Dijkstra, or A*.
- Click **Find Path**.
- The selected path is drawn on the map. The result panel displays path nodes, graph distance, visited-node count, and execution time.

## Algorithms
- **BFS:** finds a path with the fewest edges in an unweighted graph.
- **DFS:** explores one branch deeply before backtracking; it does not guarantee the shortest path.
- **Dijkstra:** finds a minimum-total-weight path for non-negative edge weights.
- **A\*:** uses straight-line geographic distance as a heuristic with the demonstration edge weights.

## Important project limitation
The graph is manually defined for an academic demonstration. Its edges and weights are illustrative and do not represent all real roads, live traffic, or Google Maps' road-routing network. The displayed line connects the selected graph nodes.

## Suggested demo
1. Start the server.
2. Select Uttara as source and Motijheel as destination.
3. Run Dijkstra and take a screenshot showing the route and metrics.
4. Run BFS or DFS for comparison.
5. Take a screenshot of the map and result panel for the report.

## Project structure
- `pathfinder/graph.py`: 15 nodes and weighted edges.
- `pathfinder/algorithms.py`: BFS, DFS, Dijkstra, and A* implementations.
- `pathfinder/views.py`: Django pages and JSON API endpoint.
- `templates/index.html`: application layout.
- `static/js/map.js`: Google Maps and frontend interaction.
- `static/css/style.css`: styling.
