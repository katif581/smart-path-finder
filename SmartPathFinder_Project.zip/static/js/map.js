let map;
let routeLine = null;
let markers = [];

function initMap() {
  const center = { lat: 23.7700, lng: 90.4000 };
  map = new google.maps.Map(document.getElementById("map"), {
    center, zoom: 12, mapTypeControl: true, streetViewControl: false
  });

  const source = document.getElementById("source");
  const destination = document.getElementById("destination");
  Object.keys(NODES).forEach((name) => {
    source.add(new Option(name, name));
    destination.add(new Option(name, name));
  });
  source.value = "Uttara";
  destination.value = "Motijheel";

  Object.entries(NODES).forEach(([name, position]) => {
    new google.maps.Marker({ map, position, title: name });
  });
}

function clearRoute() {
  if (routeLine) routeLine.setMap(null);
  markers.forEach(marker => marker.setMap(null));
  markers = [];
  routeLine = null;
}

document.getElementById("findButton").addEventListener("click", async () => {
  const button = document.getElementById("findButton");
  const result = document.getElementById("result");
  button.disabled = true;
  result.textContent = "Calculating path...";
  clearRoute();

  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-CSRFToken": getCookie("csrftoken") },
      body: JSON.stringify({
        start: document.getElementById("source").value,
        goal: document.getElementById("destination").value,
        algorithm: document.getElementById("algorithm").value
      })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Could not calculate route.");
    if (!data.path.length) throw new Error("No route found.");

    const pathCoordinates = data.path.map(name => NODES[name]);
    routeLine = new google.maps.Polyline({
      path: pathCoordinates, geodesic: true, strokeColor: "#e63946",
      strokeOpacity: 1, strokeWeight: 5, map
    });
    markers.push(new google.maps.Marker({
      map, position: pathCoordinates[0], label: "S", title: "Source: " + data.path[0]
    }));
    markers.push(new google.maps.Marker({
      map, position: pathCoordinates[pathCoordinates.length - 1],
      label: "D", title: "Destination: " + data.path[data.path.length - 1]
    }));
    const bounds = new google.maps.LatLngBounds();
    pathCoordinates.forEach(point => bounds.extend(point));
    map.fitBounds(bounds);

    result.innerHTML = `<strong>${data.algorithm}</strong><br>
      <strong>Path:</strong> ${data.path.join(" → ")}<br>
      <strong>Total graph distance:</strong> ${data.distance_km ?? "N/A"} km<br>
      <strong>Visited nodes:</strong> ${data.visited_nodes}<br>
      <strong>Execution time:</strong> ${data.execution_time_ms} ms`;
  } catch (error) {
    result.textContent = error.message;
  } finally {
    button.disabled = false;
  }
});

document.getElementById("resetButton").addEventListener("click", () => {
  clearRoute();
  document.getElementById("result").textContent = "Choose two locations and an algorithm.";
  map.setCenter({ lat: 23.7700, lng: 90.4000 });
  map.setZoom(12);
});

function getCookie(name) {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(";").shift();
}
window.initMap = initMap;
