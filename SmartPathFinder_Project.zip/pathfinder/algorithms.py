from collections import deque
import heapq
import math

def reconstruct_path(parent, start, goal):
    if goal != start and goal not in parent:
        return []
    path = [goal]
    while path[-1] != start:
        path.append(parent[path[-1]])
    return list(reversed(path))

def bfs(graph, start, goal):
    queue = deque([start])
    parent = {}
    visited = {start}
    while queue:
        current = queue.popleft()
        if current == goal:
            return reconstruct_path(parent, start, goal), len(visited)
        for neighbor in graph[current]:
            if neighbor not in visited:
                visited.add(neighbor)
                parent[neighbor] = current
                queue.append(neighbor)
    return [], len(visited)

def dfs(graph, start, goal):
    stack = [start]
    parent = {}
    visited = set()
    while stack:
        current = stack.pop()
        if current in visited:
            continue
        visited.add(current)
        if current == goal:
            return reconstruct_path(parent, start, goal), len(visited)
        # Reverse sorted order makes traversal repeatable.
        for neighbor in sorted(graph[current], reverse=True):
            if neighbor not in visited and neighbor not in parent:
                parent[neighbor] = current
                stack.append(neighbor)
    return [], len(visited)

def dijkstra(graph, start, goal):
    distances = {node: math.inf for node in graph}
    distances[start] = 0
    parent = {}
    heap = [(0, start)]
    visited = set()
    while heap:
        distance, current = heapq.heappop(heap)
        if current in visited:
            continue
        visited.add(current)
        if current == goal:
            return reconstruct_path(parent, start, goal), len(visited), distance
        for neighbor, weight in graph[current].items():
            new_distance = distance + weight
            if new_distance < distances[neighbor]:
                distances[neighbor] = new_distance
                parent[neighbor] = current
                heapq.heappush(heap, (new_distance, neighbor))
    return [], len(visited), None

def haversine_km(a, b):
    radius = 6371
    lat1, lon1 = math.radians(a["lat"]), math.radians(a["lng"])
    lat2, lon2 = math.radians(b["lat"]), math.radians(b["lng"])
    dlat, dlon = lat2 - lat1, lon2 - lon1
    value = math.sin(dlat / 2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2)**2
    return 2 * radius * math.asin(math.sqrt(value))

def astar(graph, coordinates, start, goal):
    frontier = [(0, start)]
    g_score = {node: math.inf for node in graph}
    g_score[start] = 0
    parent = {}
    visited = set()
    while frontier:
        _, current = heapq.heappop(frontier)
        if current in visited:
            continue
        visited.add(current)
        if current == goal:
            return reconstruct_path(parent, start, goal), len(visited), g_score[goal]
        for neighbor, weight in graph[current].items():
            tentative = g_score[current] + weight
            if tentative < g_score[neighbor]:
                g_score[neighbor] = tentative
                parent[neighbor] = current
                estimate = haversine_km(coordinates[neighbor], coordinates[goal])
                heapq.heappush(frontier, (tentative + estimate, neighbor))
    return [], len(visited), None
