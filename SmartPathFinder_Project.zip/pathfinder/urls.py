from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("find-path/", views.find_path, name="find_path"),
]
