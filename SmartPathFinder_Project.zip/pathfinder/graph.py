"""
A small demonstration graph with 15 locations around central Dhaka.
Coordinates are illustrative map points; graph edges define the routes
available to the algorithms (they are not live road-network data).
"""
NODES = {
    "Uttara": {"lat": 23.8759, "lng": 90.3795},
    "Airport": {"lat": 23.8514, "lng": 90.4050},
    "Banani": {"lat": 23.7937, "lng": 90.4066},
    "Gulshan": {"lat": 23.7925, "lng": 90.4078},
    "Mohakhali": {"lat": 23.7808, "lng": 90.4070},
    "Tejgaon": {"lat": 23.7639, "lng": 90.4050},
    "Farmgate": {"lat": 23.7578, "lng": 90.3890},
    "Dhanmondi": {"lat": 23.7461, "lng": 90.3742},
    "Shahbagh": {"lat": 23.7389, "lng": 90.3956},
    "Motijheel": {"lat": 23.7333, "lng": 90.4172},
    "Badda": {"lat": 23.7806, "lng": 90.4250},
    "Rampura": {"lat": 23.7638, "lng": 90.4200},
    "Khilgaon": {"lat": 23.7500, "lng": 90.4250},
    "Lalbagh": {"lat": 23.7180, "lng": 90.3880},
    "Sadarghat": {"lat": 23.7090, "lng": 90.4070},
}

# Undirected weighted edges. Weight is an illustrative distance in km.
EDGES = [
    ("Uttara", "Airport", 5), ("Airport", "Banani", 7),
    ("Banani", "Gulshan", 2), ("Banani", "Mohakhali", 3),
    ("Gulshan", "Badda", 4), ("Badda", "Rampura", 4),
    ("Mohakhali", "Tejgaon", 3), ("Tejgaon", "Farmgate", 2),
    ("Farmgate", "Dhanmondi", 4), ("Farmgate", "Shahbagh", 3),
    ("Dhanmondi", "Lalbagh", 5), ("Shahbagh", "Lalbagh", 4),
    ("Shahbagh", "Motijheel", 4), ("Motijheel", "Khilgaon", 4),
    ("Khilgaon", "Rampura", 3), ("Lalbagh", "Sadarghat", 3),
    ("Sadarghat", "Motijheel", 5), ("Tejgaon", "Rampura", 5),
    ("Gulshan", "Mohakhali", 3), ("Dhanmondi", "Shahbagh", 4),
]

def build_graph():
    graph = {node: {} for node in NODES}
    for a, b, weight in EDGES:
        graph[a][b] = weight
        graph[b][a] = weight
    return graph
