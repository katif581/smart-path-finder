import json
import time
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.http import require_POST
from .graph import NODES, build_graph
from .algorithms import bfs, dfs, dijkstra, astar

def index(request):
    return render(request, "index.html", {
        "nodes_json": json.dumps(NODES),
        "google_maps_api_key": "YOUR_GOOGLE_MAPS_API_KEY",
    })

@require_POST
def find_path(request):
    try:
        payload = json.loads(request.body)
        start, goal = payload.get("start"), payload.get("goal")
        algorithm = payload.get("algorithm", "dijkstra").lower()
        if start not in NODES or goal not in NODES:
            return JsonResponse({"error": "Please select valid source and destination nodes."}, status=400)
        if start == goal:
            return JsonResponse({"error": "Source and destination must be different."}, status=400)

        graph = build_graph()
        started = time.perf_counter()
        if algorithm == "bfs":
            path, visited = bfs(graph, start, goal)
            distance = sum(graph[a][b] for a, b in zip(path, path[1:])) if path else None
        elif algorithm == "dfs":
            path, visited = dfs(graph, start, goal)
            distance = sum(graph[a][b] for a, b in zip(path, path[1:])) if path else None
        elif algorithm == "astar":
            path, visited, distance = astar(graph, NODES, start, goal)
        elif algorithm == "dijkstra":
            path, visited, distance = dijkstra(graph, start, goal)
        else:
            return JsonResponse({"error": "Unsupported algorithm."}, status=400)

        elapsed_ms = (time.perf_counter() - started) * 1000
        return JsonResponse({
            "path": path,
            "distance_km": round(distance, 2) if distance is not None else None,
            "visited_nodes": visited,
            "execution_time_ms": round(elapsed_ms, 4),
            "algorithm": algorithm.upper(),
            "coordinates": {name: NODES[name] for name in path},
        })
    except (ValueError, TypeError, KeyError):
        return JsonResponse({"error": "Invalid request data."}, status=400)
